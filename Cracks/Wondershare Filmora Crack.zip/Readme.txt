1. Install Filmora as you normally do
2. Move the Activator.exe to "C:\Program Files\Wondershare\Wondershare Filmora"
3. Run Activtor.exe
4. Enjoy!
